function returnNums (arr) {
    for(i=0;i<=255;i++) {
        arr.push(i) ;
    }
    return arr
}
console.log(returnNums([]));