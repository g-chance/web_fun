function sumEven() {
    var sum = 0;
    for(i=0;i<=1000;i++) {
        if(i%2 === 0) {
            sum += i;
        }
    }
    return sum;
}
console.log(sumEven());